from setuptools import setup


setup(
      name='xmm_simulator',    # This is the name of your PyPI-package.
      version='0.1.0',
      description='XMM photon simulator from boxes extracted from hydro sims',
      author='Dominique Eckert',
      author_email='Dominique.Eckert@unige.ch',
      #url="https://github.com/domeckert/pyproffit",
      packages=['xmm_simulator'],
      install_requires=[
            'numpy','scipy','astropy','matplotlib','pyatomdb','threeML',
      ],
      data_files=[('xmm_simulator/rmfs', ['xmm_simulator/rmfs/PN.rmf',
                                          'xmm_simulator/rmfs/MOS1.rmf',
                                          'xmm_simulator/rmfs/MOS2.rmf']),
                  ('xmm_simulator/imgs', ['xmm_simulator/imgs/MOS1_mask.fits.gz',
                                          'xmm_simulator/imgs/MOS2_mask.fits.gz',
                                          'xmm_simulator/imgs/PN_mask.fits.gz'])]
)

